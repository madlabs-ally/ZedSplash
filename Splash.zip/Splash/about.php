<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="assets/Madlabs.png">

    <title> ZedSplash - About Us</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="css/ie10-viewport-bug-workaround.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/about.css" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="js/ie-emulation-modes-warning.js"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="respond.min.js"></script>
    <![endif]-->
  </head>

  <body>

    <!-- Fixed navbar -->
    <nav class="navbar navbar-default navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="index.php">ZedSplash</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li class="active"><a href="artists.php">Artists</a></li>
            <li><a href="about.php">About</a></li>
            <li><a href="contact.php">Contact</a></li>
            <li><a href="login/login.php">Login</a></li>
            <li><a href="faq.php">FAQs</a></li>
            <li class="dropdown">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Promo's<span class="caret"></span></a>
                  <ul class="dropdown-menu">
                    <li><a href="videos.php">Video</a></li>
                    <li><a href="audios.php">Audios</a></li>
                    <li><a href="businesses.php">Businesses</a></li>
                  </ul>
                </li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>

    <div class="container">

      <!-- Main component for a primary marketing message or call to action -->
      <div class="jumbotron text-center">
      <h1>About Us</h1> 
      <hr>
      <h4>Who we are..</h4>
    <h5>ZedSplash is a platform that promotes Talents, Skills and Businesses among Youths. 
    It is a site that will help you make you Skill, Business and Talent a success, all you need is to Create a ZedSplash account then create a channel, then you will be set to upload your own Videos, Audios and Pictures at your own desired time and anywhere you are.</h5> 
  <h4>Our Mission..</h4>
  <h5>Our mission is to be the best Entertainment and Promotion Platform in Zambia and the World at large.</h5>
    <br>
    <h4>Our Aim</h4>
    <h5>Our aim is to reduce the high unemployment and poverty levels in Africa through the promotion of talents, skills and businesses among youths.</h5>
    <h4>Our Vision..</h4>
  <h5>Our vision is to become the best Zambian entertainment and promotion platform.</h5>
  <h4>Our Services</h4>
  <h5>1. Music Promotion.</h5>
  <h5>2. Business Promotion.</h5>
  <h5>3. Skills' and Talents' Promotion.</h5>
  <h5>4. Graphic Designing.</h5>
  <h5>5. Web Design and Development</h5>
</div>
    </div> <!-- /container -->


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="js/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery.min.js"><\/script>')</script>
    <script src="js/bootstrap.min.js"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="js/ie10-viewport-bug-workaround.js"></script>
  </body>
</html>
