<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../assets/Madlabs.png">
    <title> ZedSplash - J Stone</title>
    <link href="../../css/bootstrap.min.css" rel="stylesheet">
    <link href="../../css/ie10-viewport-bug-workaround.css" rel="stylesheet">
    <link href="jstone.css" rel="stylesheet">
    <script src="../../js/ie-emulation-modes-warning.js"></script>
  </head>

  <body>
    <nav class="navbar navbar-default navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="index.php">ZedSplash</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li class="active"><a href="artists.php">Artists</a></li>
            <li><a href="about.php">About</a></li>
            <li><a href="contact.php">Contact</a></li>
            <li><a href="videos.php">Videos</a></li>
            <li><a href="audios.php">Audios</a></li>
            <li><a href="faq.php">FAQs</a></li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>

    <div class="container">
      <h1>J - Stone</h1>
      <!-- Main component for a primary marketing message or call to action -->
      <div class="jumbotron">
      <img src="jstone.jpg" alt="" style="width:100%;">
      </div>
      <div class="jumbotron">
<audio  controls>
        <source src="J-Stonne_Kaso Kuch_Y-See -He is coming---Prodz By Sky P.mp3">   
    </audio>
    <br>
    <p>J-Stonne_Kaso Kuch_Y-See -He is coming---Prodz By Sky P</p>
    <a href="J-Stonne_Kaso Kuch_Y-See -He is coming---Prodz By Sky P.mp3" download="J-Stonne_Kaso Kuch_Y-See -He is coming---Prodz By Sky P">
    <button class="button">Download This Song</button></a>
    <br>
    <audio  controls>
        <source src="NIPASE - J-Stone ft JJ Samuel.mp3">   
    </audio>
    <br>
    <p>NIPASE - J-Stone ft JJ Samuel</p>
    <a href="n.php">
    <button class="button">Download This Song</button></a>
</div>
    </div> <!-- /container -->


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="../../js/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery.min.js"><\/script>')</script>
    <script src="../../js/bootstrap.min.js"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="../../js/ie10-viewport-bug-workaround.js"></script>
  </body>
</html>
