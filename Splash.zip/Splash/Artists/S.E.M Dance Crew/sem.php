<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../assets/Madlabs.png">

    <title>ZedSplash - S.E.M Crew</title>

    <!-- Bootstrap core CSS -->
    <link href="../../css/bootstrap.min.css" rel="stylesheet">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="../../css/ie10-viewport-bug-workaround.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="sem.css" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="../../js/ie-emulation-modes-warning.js"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="respond.min.js"></script>
    <![endif]-->
  </head>

  <body>

    <!-- Fixed navbar -->
    <nav class="navbar navbar-default navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="../../index.php">ZedSplash</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li class="active"><a href="../../artists.php">Artists</a></li>
            <li><a href="../../about.php">About</a></li>
            <li><a href="../../contact.php">Contact</a></li>
            <li><a href="../../videos.php">Videos</a></li>
            <li><a href="../../audios.php">Audios</a></li>
            <li><a href="../../faq.php">FAQs</a></li>
           
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>

    <div class="container">

      <!-- Main component for a primary marketing message or call to action -->
      <h1>S.E.M Dance Crew</h1>
      <div class="jumbotron" style="height:100%">
       <img src="../../assets/SEM.jpg" alt="" style="width:100%">
      </div>
      <div class="jumbotron">
      <div class="upload-video">
      <video controls src="Didololo by Marlians.mp4" style="width:100%;"></video>
      <p>S.E.M Dance Crew - "Didololo" by Marlians</p>
      <a href="Didololo by Marlians.mp4" download="SEM Dance Crew - Didololo by Marlians">
    <button class="button">Download This Dance Video</button></a>
      </div>
      <br>
      <div class="upload-video">
      <video controls src="Savem (2).mp4" style="width:100%"></video>
      <p>S.E.M Dance Crew - "Mbo" by Chanda_Na_Kay</p>
      <a href="Savem (2).mp4" download="SEM Dance Crew - Mbo by Chanda_Na_Kay">
    <button class="button">Download This Dance Video</button></a>
      </div>
      <br>
      <div class="upload-video">
      <video controls src="Savem (3).mp4" style="width:100%"></video>
     <p>S.E.M Dance Crew - "Very Very" by Venture Man ft Spark-Rizzo </p>
     <a href="Savem (3).mp4" download="SEM Dance Crew - Very Very by Venture Man ft Spark-Rizzo ">
    <button class="button">Download This Dance Video</button></a>
      </div>
      <br>
      <div class="upload-video">
      <video controls src="Savem (4).mp4" style="width:100%"></video>
      <p>S.E.M Dance Crew - "Woah official dance video" by Krypto9095</p>
      <a href="Savem (4).mp4" download="SEM Dance Crew - Woah official dance video by Krypto9095">
    <button class="button">Download This Dance Video</button></a>
      </div>
      <br>
      <div class="upload-video">
      <video controls src="Savem (5).mp4" style="width:100%"></video>
      <p>S.E.M Dance Crew - "Pilolo" by GuiltyBeatz, Kwesi Arthur and Mr Eazi</p>
      <a href="Savem (5).mp4" download="SEM Dance Crew - Pilolo by GuiltyBeatz Kwesi Arthur and Mr Eazi">
    <button class="button">Download This Dance Video</button></a>
      </div>
      <br>
</div>
    </div> <!-- /container -->


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="../../js/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery.min.js"><\/script>')</script>
    <script src="../../js/bootstrap.min.js"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="../../js/ie10-viewport-bug-workaround.js"></script>
  </body>
</html>
