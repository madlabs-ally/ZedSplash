<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../assets/Madlabs.png">

    <title>ZedSplash - Jnana</title>

    <!-- Bootstrap core CSS -->
    <link href="../../css/bootstrap.min.css" rel="stylesheet">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="../../css/ie10-viewport-bug-workaround.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="jnana.css" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="../../js/ie-emulation-modes-warning.js"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="respond.min.js"></script>
    <![endif]-->
  </head>

  <body>

    <!-- Fixed navbar -->
    <nav class="navbar navbar-default navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="index.php">ZedSplash</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li class="active"><a href="../../artists.php">Artists</a></li>
            <li><a href="../../about.php">About</a></li>
            <li><a href="../../contact.php">Contact</a></li>
            <li><a href="../../videos.php">Videos</a></li>
            <li><a href="../../audios.php">Audios</a></li>
           <li><a href="../../faq.php">FAQs</a></li>
        </div><!--/.nav-collapse -->
      </div>
    </nav>

    <div class="container">

      <!-- Main component for a primary marketing message or call to action -->
      <h1>Kopala Jnana</h1>
      <div class="jumbotron">
        <img src="../../assets/jnana.jpg" alt="" style="width:100%;">
      </div>
      <div class="jumbotron">
      <audio class="media"  controls>
        <source src="J_Nana_ft_Guy_Cooper_-_you_lose_my_mind.mp3">   
    </audio>
    <br>
    <p>J Nana ft Guy Cooper - You Lose My Mind</p>
    <a href="ylmm.php">
    <button class="button">Download This Song</button></a>
    <br>
    <audio class="media"  controls>
        <source src="J_Nana_Ft_Krypton,Chong_Lee_,_Guy_Cooper-Crying_For_U_(BizoBitx_Pandombo).mp3">    
    </audio>
    <p>J_Nana_Ft_Krypton,Chong_Lee <br> _,_Guy_Cooper-Crying_For_ <br> U_(BizoBitx_Pandombo)</p>
    <a href="cfy.php"><button class="button">Download This song</button></a>
   <br> 
    <audio class="media" controls>
        <source src="J`nana Baby you ma.mp3">    
    </audio>
    <p>J`nana Baby you ma</p>
    <a href="bym.php"><button class="button">Download This song</button></a>
    <br>
    <audio class="media" controls>
        <source src="Jay_Nana_ft_Brown_Bizzo--X--Smark_(_Prodz_By_YoungSmark).mp3">   
    </audio>
    <p>Jay_Nana_ft_Brown_Bizzo--X--Smark_(_Prodz_By_YoungSmark)</p>
    <a href="Bizzo.php"><button class="button">Download This song</button></a>
   <br>
   <audio class="media" controls>
        <source src="Jay_Nana_ft_Hyper_DY_-_Nikulangize.mp3">   
    </audio>
    <p>Jay_Nana_ft_Hyper_DY_-_Nikulangize</p>
    <a href="n.php"><button class="button">Download This song</button></a>
   <br>
   <audio class="media" controls>
        <source src="Kopala_Jay_nana_-_For_real_(prod_by_Dj_fame).mp3">   
    </audio>
    <p>Kopala_Jay_nana_-_For_real_ <br>
    (prod_by_Dj_fame)</p>
    <a href="fr.php"><button class="button">Download This song</button></a>
   <br>
   <audio class="media" controls>
        <source src="Kopala_Jay_nana_and__Hyper_D_Y_.mp3">   
    </audio>
    <p>Kopala_Jay_nana_and__ <br> Hyper_D_Y_</p>
    <a href="Hyper.php"><button class="button">Download This song</button></a>
   <br>
   <audio class="media" controls>
        <source src="Kopala_Jay_nana_ft_Chizzy_boy_-_you_are_my_lover_(prod_by_Dj_Fame45)_-_Outpu.mp3">   
    </audio>
    <p>Kopala_Jay_nana_ft_Chizzy_boy <br> _-_you_are_my_lover_(prod_by <br> _Dj_Fame45)_-_Output</p>
    <a href="yaml.php"><button class="button">Download This song</button></a>
   <br>
   <audio class="media" controls>
        <source src="NANO_FT_JAE_NANA_-_Output_-_Stereo_Out.mp3">   
    </audio>
    <p>NANO_FT_JAE_NANA - Your Lover</p>
    <a href="nano.php"><button class="button">Download This song</button></a>
   <br>
   <audio class="media" controls>
        <source src="THE_WAY_U_ARE--Jay_nana--HYPER_D-Y--PRODZ_BY_CHIZZY.mp3">   
    </audio>
    <p>THE_WAY_U_ARE--Jay_nana--HYPER_D-Y--PRODZ_BY_CHIZZY</p>
    <a href="twya.php"><button class="button">Download This song</button></a>
   <br>
   <audio class="media" controls>
        <source src="THE_WAY_U_ARE--Jay_nana--HYPER_D-Y--PRODZ_BY_CHIZZY.mp3">   
    </audio>
    <p>We_Feelin_Laka - Jnana</p>
    <a href="wfl.php"><button class="button">Download This song</button></a>
   <br>
       </div>
    </div> <!-- /container -->

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="../../js/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery.min.js"><\/script>')</script>
    <script src="../../js/bootstrap.min.js"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="../../js/ie10-viewport-bug-workaround.js"></script>
  </body>
</html>
